This is the private folder for file access per user with jWebSocket.
Please remove this file in your jWebSocket production environment.