This is the public folder for shared file access with jWebSocket.
Please remove this file in your jWebSocket production environment.