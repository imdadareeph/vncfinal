This folder contains the Derby or SQLite databases for the persistence engines.
Derby is used as default storage engine.
You can configure any other JDBC database in the plug-in configuration files.